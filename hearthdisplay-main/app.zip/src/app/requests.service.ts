import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Headers,RequestOptions } from '@angular/http';
import { map } from 'rxjs/operators';
import { LoadingController,ToastController,AlertController  } from '@ionic/angular';
import { Observable,Subscription } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class RequestsService {
  link:any;
  set_profile:any=[];
  constructor( private router:Router,public http: Http,
    public loadingController: LoadingController,
    public toastController:ToastController,
    ) { 
      this.link = 'https://propuae.com/hearth_api/api.php';
    }
    register(name,email,password):Observable<any[]>{
      let postData = new FormData();
      postData.append('type','register');
      postData.append('name',name);
      postData.append('password',password);
      postData.append('email',email);
     return this.http.post(this.link,postData).pipe(map(res=>res.json()))
    }
      login(email,password):Observable<any[]>{
        let postData = new FormData();
        postData.append('type','login');
        postData.append('password',password);
        postData.append('email',email);
      return this.http.post(this.link,postData).pipe(map(res=>res.json()))
     }
     profile(user_id):Observable<any[]>{
      let postData = new FormData();
      postData.append('type','profile');
      postData.append('user_id',user_id);
    return this.http.post(this.link,postData).pipe(map(res=>res.json()))
   }
   save_profile(first_name,last_name,dob,phone,notes,email,user_id,profile_pic):Observable<any[]>{
    let postData = new FormData();
    postData.append('type','save_profile');
    postData.append('user_id',user_id);
    postData.append('first_name',first_name);
    postData.append('last_name',last_name);
    postData.append('dob',dob);
    postData.append('phone',phone);
    postData.append('notes',notes);
    postData.append('email',email);   
    postData.append('img',profile_pic) 
    return this.http.post(this.link,postData).pipe(map(res=>res.json()))
   }
   add_profile(first_name,last_name,dob,phone,notes,email,password,user_id,profile_pic):Observable<any[]>{
    let postData = new FormData();
    postData.append('type','add_profile');
    postData.append('user_id',user_id);
    postData.append('first_name',first_name);
    postData.append('last_name',last_name);
    postData.append('dob',dob);
    postData.append('phone',phone);
    postData.append('notes',notes);
    postData.append('email',email);
    postData.append('password',password );  
    postData.append('img',profile_pic) 
    return this.http.post(this.link,postData).pipe(map(res=>res.json()))
   }
   all_profiles(user_id):Observable<any[]>{
    let postData = new FormData();
    postData.append('type','all_profiles');
    postData.append('user_id',user_id);
    return this.http.post(this.link,postData).pipe(map(res=>res.json()))
   }
   profile_detail(user_id):Observable<any[]>{
    let postData = new FormData();
    postData.append('type','profile_detail');
    postData.append('user_id',user_id);
    return this.http.post(this.link,postData).pipe(map(res=>res.json()))
   }
   add_event(title,des,start_time,end_time,user_id,date,time):Observable<any[]>{
    let postData = new FormData();
    postData.append('type','add_event');
    postData.append('title',title);
    postData.append('des',des);
    postData.append('start_time',start_time);
    postData.append('end_time',end_time);
    postData.append('date',date)
    postData.append('time',time)
    postData.append('user_id',user_id);
    return this.http.post(this.link,postData).pipe(map(res=>res.json()))
   }
   get_events(user_id):Observable<any[]>{
    let postData = new FormData();
    postData.append('type','get_events');
    postData.append('user_id',user_id);
    return this.http.post(this.link,postData).pipe(map(res=>res.json()))
   }
   child_events(user_id,currentDate,currentTime):Observable<any[]>{
    let postData = new FormData();
    postData.append('type','child_events');
    postData.append('user_id',user_id);
    postData.append('currentDate',currentDate);
    postData.append('currentTime',currentTime);
    return this.http.post(this.link,postData).pipe(map(res=>res.json()))
   }
   child_front_screen(user_id):Observable<any[]>{
    let postData = new FormData();
    postData.append('type','child_front_screen');
    postData.append('user_id',user_id);
    return this.http.post(this.link,postData).pipe(map(res=>res.json()))
   }
   setData(first_name,last_name,email,dob,phone,notes,profile_pic){
    this.set_profile = {first_name:first_name,last_name:last_name,email:email,dob:dob,phone:phone,notes:notes,profile_pic:profile_pic}
   }
   getData(){
     return this.set_profile;
   }
}
