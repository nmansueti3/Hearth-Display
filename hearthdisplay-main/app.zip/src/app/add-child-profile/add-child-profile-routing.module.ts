import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddChildProfilePage } from './add-child-profile.page';

const routes: Routes = [
  {
    path: '',
    component: AddChildProfilePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AddChildProfilePageRoutingModule {}
