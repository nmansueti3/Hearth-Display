import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BabyCompleteRoutinePageRoutingModule } from './baby-complete-routine-routing.module';

import { BabyCompleteRoutinePage } from './baby-complete-routine.page';
import { NgCircleProgressModule } from 'ng-circle-progress';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NgCircleProgressModule.forRoot({
      radius: 100,
      outerStrokeWidth: 12,
      innerStrokeWidth: 8,
      outerStrokeColor: "#78C000",
      innerStrokeColor: "#C7E596",
      animationDuration: 300,
    }),
    BabyCompleteRoutinePageRoutingModule,
  ],
  declarations: [BabyCompleteRoutinePage]
})
export class BabyCompleteRoutinePageModule {}
