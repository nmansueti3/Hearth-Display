import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { FreeTimeCountdownPage } from './free-time-countdown.page';

describe('FreeTimeCountdownPage', () => {
  let component: FreeTimeCountdownPage;
  let fixture: ComponentFixture<FreeTimeCountdownPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FreeTimeCountdownPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(FreeTimeCountdownPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
