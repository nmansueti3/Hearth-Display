import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NegativeProgressModalPage } from './negative-progress-modal.page';

const routes: Routes = [
  {
    path: '',
    component: NegativeProgressModalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class NegativeProgressModalPageRoutingModule {}
