import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { RequestsService } from '../requests.service';
import { LoadingController,ToastController,AlertController  } from '@ionic/angular';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.page.html',
  styleUrls: ['./edit-profile.page.scss'],
})
export class EditProfilePage implements OnInit {
  @ViewChild('input') myInput ;
  result:any=[];
  user_id: any;
  first_name: any;
  last_name: any;
  email: any;
  dob:any;
  phone: any;
  notes: any;
  show_loader:any;
  profile_pic:any;
  constructor(public router: Router,public service:RequestsService,
    public loadingController:LoadingController,
    private camera: Camera,
    public toastController:ToastController) {
      this.show_loader = false;
      this.profile_pic = 'assets/images/image3.png';
    }

  ngOnInit() {
    
  }
  ionViewDidEnter(){
    this.myInput.setFocus();
    this.user_id = window.localStorage.getItem('user_id');
    this.result = this.service.getData();
    this.first_name = this.result['first_name'];
    this.last_name = this.result['last_name'];
    this.dob = this.result['dob'];
    this.phone = this.result['phone'];
    this.notes = this.result['notes']; 
    this.email = this.result['email'];
    this.profile_pic = this.result['profile_pic'];
  }
  back(){
    window.history.back();
  }
  save(){
    console.log(this.dob)
    let date = this.dob.split('T')
    let get_dob = date[0];
    this.show_loader = true;
    this.service.save_profile(this.first_name,this.last_name,get_dob,this.phone,
      this.notes,this.email,this.user_id,this.profile_pic).subscribe(result => {
      console.log(result)
      this.show_loader = false;
      this.showmessage('Profile Updated Successfully');
      this.router.navigate(['/profile'])
    })   
  }
  
  getImage(){
      
    const options: CameraOptions = {
      quality: 60,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
      saveToPhotoAlbum: false,
    }
    this.camera.getPicture(options).then((imageData) => {
      //console.log(imageData)
      this.profile_pic = 'data:image/jpeg;base64,' + imageData;
     
    }, (error) => {
      console.log(error);
    });

  }
  async showmessage(message){
    var toast = await this.toastController.create({
      message: message,
      cssClass: 'alert-controller-css',
      color:'success',
      duration: 3000
    });
    toast.present();
   
    }
}
