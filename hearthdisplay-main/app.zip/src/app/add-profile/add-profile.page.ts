import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
@Component({
  selector: 'app-add-profile',
  templateUrl: './add-profile.page.html',
  styleUrls: ['./add-profile.page.scss'],
})
export class AddProfilePage implements OnInit {

  constructor(public navCtrl: NavController) { }

  ngOnInit() {
  }
  skip(){
    this.navCtrl.navigateForward('profile', { animated: false, });
  }
  add_profile(){
    this.navCtrl.navigateForward('profile', { animated: false});
  }
}
