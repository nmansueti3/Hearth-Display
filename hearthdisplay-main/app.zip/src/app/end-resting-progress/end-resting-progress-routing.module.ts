import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EndRestingProgressPage } from './end-resting-progress.page';

const routes: Routes = [
  {
    path: '',
    component: EndRestingProgressPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EndRestingProgressPageRoutingModule {}
