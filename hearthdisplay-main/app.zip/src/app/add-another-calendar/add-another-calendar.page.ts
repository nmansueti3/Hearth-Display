import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add-another-calendar',
  templateUrl: './add-another-calendar.page.html',
  styleUrls: ['./add-another-calendar.page.scss'],
})
export class AddAnotherCalendarPage implements OnInit {

  constructor(public router: Router) { }

  ngOnInit() {
  }
  back(){
    window.history.back()
  }
  connect(){
    this.router.navigate(['connect-my-calendar'])
  }
}
