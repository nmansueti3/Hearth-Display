import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddMoreProfilePageRoutingModule } from './add-more-profile-routing.module';

import { AddMoreProfilePage } from './add-more-profile.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AddMoreProfilePageRoutingModule
  ],
  declarations: [AddMoreProfilePage]
})
export class AddMoreProfilePageModule {}
