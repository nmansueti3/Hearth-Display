
import { Component, ViewChild, OnInit, Inject, LOCALE_ID } from '@angular/core';

@Component({
  selector: 'app-connect-calendars',
  templateUrl: './connect-calendars.page.html',
  styleUrls: ['./connect-calendars.page.scss'],
})
export class ConnectCalendarsPage implements OnInit {

 
 
  constructor() { }
 
  ngOnInit() {
  
  }
 
}