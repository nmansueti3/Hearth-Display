import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
@Component({
  selector: 'app-connect-calendar',
  templateUrl: './connect-calendar.page.html',
  styleUrls: ['./connect-calendar.page.scss'],
})
export class ConnectCalendarPage implements OnInit {
  selectcalendar:any;  
  gmail:any;

  constructor(public navCtrl: NavController) { 

  }

  ngOnInit() {
  }
back(){
  window.history.back();
}
connect_gmail(type){
  if(type=='gmail'){
    this.gmail=true;
  }
}
next(){
 // this.navCtrl.navigateForward('google-calendar', { animated: false, });
 this.navCtrl.navigateForward('end-resting-progress', { animated: false, });
}
}
