import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-calendar',
  templateUrl: './view-calendar.page.html',
  styleUrls: ['./view-calendar.page.scss'],
})
export class ViewCalendarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
