import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddMoreProfilePage } from './add-more-profile.page';

const routes: Routes = [
  {
    path: '',
    component: AddMoreProfilePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AddMoreProfilePageRoutingModule {}
