import { NgModule,LOCALE_ID } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EndRestingProgressPageRoutingModule } from './end-resting-progress-routing.module';

import { EndRestingProgressPage } from './end-resting-progress.page';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { CalModalPageModule } from '../pages/cal-modal/cal-modal.module';
import { NgCalendarModule  } from 'ionic2-calendar';
import { registerLocaleData } from '@angular/common';
import localeDe from '@angular/common/locales/de';
registerLocaleData(localeDe);
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NgCalendarModule,
   // CalModalPageModule,
    NgCircleProgressModule.forRoot({
      radius: 100,
      outerStrokeWidth: 12,
      innerStrokeWidth: 0,
      outerStrokeColor: "#78C000",
      animationDuration: 300,
    }),
    EndRestingProgressPageRoutingModule
  ],
  declarations: [EndRestingProgressPage],
  providers: [
    { provide: LOCALE_ID, useValue: 'en-us' }
  ]
})
export class EndRestingProgressPageModule {}
