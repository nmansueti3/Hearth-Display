import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GoogleCalendarPageRoutingModule } from './google-calendar-routing.module';

import { GoogleCalendarPage } from './google-calendar.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GoogleCalendarPageRoutingModule
  ],
  declarations: [GoogleCalendarPage]
})
export class GoogleCalendarPageModule {}
