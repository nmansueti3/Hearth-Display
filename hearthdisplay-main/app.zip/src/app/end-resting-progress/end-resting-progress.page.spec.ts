import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { EndRestingProgressPage } from './end-resting-progress.page';

describe('EndRestingProgressPage', () => {
  let component: EndRestingProgressPage;
  let fixture: ComponentFixture<EndRestingProgressPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EndRestingProgressPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(EndRestingProgressPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
