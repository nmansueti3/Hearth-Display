import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { RequestsService } from '../requests.service';
import { LoadingController,ToastController,AlertController  } from '@ionic/angular';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
user_id: any;
first_name: any;
last_name: any;
email: any;
dob:any;
phone: any;
notes: any;
profile_pic: any;
  constructor(public navCtrl: NavController,public alertController: AlertController,
    public service:RequestsService,public loadingController:LoadingController) { }

  ngOnInit() {
  }
  async ionViewDidEnter(){
    this.user_id = window.localStorage.getItem('user_id');
    let loading = await this.loadingController.create({
      showBackdrop: false,
      mode: 'ios',
      cssClass: 'custom-loading'
  });
  
  loading.present().then(() => {
  this.service.profile(this.user_id).subscribe(res => {
    console.log(res)
    loading.dismiss();
    this.first_name = res['profile']['name'];
    this.last_name = res['profile']['last_name'];
    this.email = res['profile']['email'];
    this.dob = res['profile']['birthday'];
    this.phone = res['profile']['phone_number'];
    this.notes = res['profile']['notes'];
    this.profile_pic = res['profile']['pic'];
    this.service.setData(this.first_name,this.last_name,this.email,this.dob,this.phone,
      this.notes,this.profile_pic);
  })
  });
  }
  back(){
    window.history.back();
  }
  save(){
    this.navCtrl.navigateForward('add-more-profile', { animated: false, });
  }
  connect(){
    this.navCtrl.navigateForward('connect-calendar', { animated: false, });
  }
  async info() {
    const alert = await this.alertController.create({
      cssClass: 'alert-class',
      header: 'Info!',
      message: 'My complete profile is here',
      buttons: [
        {
          text: 'Okay',
          handler: () => {
            console.log('Confirm Okay');
          }
        }
      ]
    });

    await alert.present();
  }
  edit_profile(){
    this.navCtrl.navigateForward('edit-profile');
  }
}
