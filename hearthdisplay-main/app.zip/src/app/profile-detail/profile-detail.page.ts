import { Component, OnInit } from '@angular/core';;
import { NavController } from '@ionic/angular';
import { RequestsService } from '../requests.service';
import { LoadingController,ToastController,AlertController  } from '@ionic/angular';
import { Router } from '@angular/router';
@Component({
  selector: 'app-profile-detail',
  templateUrl: './profile-detail.page.html',
  styleUrls: ['./profile-detail.page.scss'],
})
export class ProfileDetailPage implements OnInit {
detail_id : any;
name:any;
email:any;
phone:any;
notes:any;
image:any;
user_type:any;
  constructor(public router: Router,
    public navCtrl: NavController,public alertController: AlertController,
    public service:RequestsService,public loadingController:LoadingController) {
    
   }

  ngOnInit() {
  }
  async ionViewDidEnter(){
   this.detail_id =  window.localStorage.getItem('detail_id')
   this.service.profile_detail(this.detail_id).subscribe(res =>{
     console.log(res)
     this.name = res['detail']['name'];
     this.email = res['detail']['email'];
     this.phone = res['detail']['phone'];
     this.notes = res['detail']['notes'];
     this.image = res['detail']['image'];
     this.user_type = res['detail']['user_type'];
   })
  }
  connect(){
    this.router.navigate(['/connect-calendar'])
  }
  back(){
    window.history.back();
  }
  edit(){
    this.router.navigate(['/edit-profile'])
  }
}
