import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { RequestsService } from '../requests.service';
import { LoadingController,ToastController,AlertController  } from '@ionic/angular';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';


@Component({
  selector: 'app-add-child-profile',
  templateUrl: './add-child-profile.page.html',
  styleUrls: ['./add-child-profile.page.scss'],
})
export class AddChildProfilePage {
  @ViewChild('input') myInput ;
  result:any=[];
  user_id: any;
  first_name: any;
  last_name: any;
  email: any;
  dob:any;
  phone: any;
  password:any;
  notes: any;
  show_loader:any;
  profile_pic:any;
  constructor(public router: Router,public service:RequestsService,
    public loadingController:LoadingController,
    private camera: Camera,
    public toastController:ToastController) {
      this.show_loader = false;
      this.profile_pic='assets/images/image1.png'
      console.log(this.profile_pic)
    }


    ionViewDidEnter(){
      this.myInput.setFocus();
      this.user_id = window.localStorage.getItem('user_id');

    }
    back(){
      window.history.back();
    }
    save(){
      console.log(this.first_name, this.last_name, this.email, this.dob, this.password)
      if(this.first_name == undefined || this.last_name == undefined || this.email == undefined || this.dob == undefined ||
       this.password == undefined ){
         this.showmessage1('Please Fill all the fields')
       }else{
      this.show_loader = true;
      let date = this.dob.split('T')
      let get_dob = date[0];
      this.service.add_profile(this.first_name,this.last_name,get_dob,this.phone,
        this.notes,this.email,this.password,this.user_id,this.profile_pic).subscribe(result => {
       console.log(result)
        this.show_loader = false;
        if(result['result']==false) {
          this.showmessage1(result['message']);
        }
        else{
        this.showmessage('Profile Added Successfully');
       this.router.navigate(['/add-more-profile'])
      }
     })   
    }
    }
    
    getImage(){
        
      const options: CameraOptions = {
        quality: 60,
        destinationType: this.camera.DestinationType.DATA_URL,
        encodingType: this.camera.EncodingType.JPEG,
        mediaType: this.camera.MediaType.PICTURE,
        sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
        saveToPhotoAlbum: false,
      }
      this.camera.getPicture(options).then((imageData) => {
        //console.log(imageData)
        this.profile_pic = 'data:image/jpeg;base64,' + imageData;
       
      }, (error) => {
        console.log(error);
      });
  
    }
    async showmessage(message){
      var toast = await this.toastController.create({
        message: message,
        cssClass: 'alert-controller-css',
        color:'success',
        duration: 3000
      });
      toast.present();
     
      }
     async showmessage1(message){
        var toast = await this.toastController.create({
          message: message,
          cssClass: 'alert-controller-css',
          color:'danger',
          duration: 3000
        });
        toast.present();
       
        }
}
