import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ConnectCalendarPageRoutingModule } from './connect-calendar-routing.module';

import { ConnectCalendarPage } from './connect-calendar.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ConnectCalendarPageRoutingModule
  ],
  declarations: [ConnectCalendarPage]
})
export class ConnectCalendarPageModule {}
