import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-connect-my-calendar',
  templateUrl: './connect-my-calendar.page.html',
  styleUrls: ['./connect-my-calendar.page.scss'],
})
export class ConnectMyCalendarPage implements OnInit {

  constructor(public router: Router) { }

  ngOnInit() {
  }
  back(){
    window.history.back();
  }
  skip(){
    this.router.navigate(['profile'])
  }
  connect(){
    this.router.navigate(['add-another-calendar'])
  }
}
