import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ConnectCalendarsPage } from './connect-calendars.page';

const routes: Routes = [
  {
    path: '',
    component: ConnectCalendarsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ConnectCalendarsPageRoutingModule {}
