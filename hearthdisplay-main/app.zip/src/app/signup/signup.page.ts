import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { RequestsService } from '../requests.service';
import { LoadingController,ToastController,AlertController  } from '@ionic/angular';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
})
export class SignupPage implements OnInit {
  show_loader:any;
  validations_form: FormGroup;
  constructor(public navCtrl: NavController,
    public formBuilder: FormBuilder, public service:RequestsService,
    public toastController:ToastController) { 
    this.show_loader=false;
  }

  ngOnInit() {
    this.validations_form = this.formBuilder.group({
      name: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
      email: new FormControl('', Validators.compose([
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),
  
     });
  }
  
  validation_messages = {
  
    'name': [
      { type: 'required', message: 'Name is required.' }
    ],
   
    'email': [
      { type: 'required', message: 'Email is required.' },
      { type: 'pattern', message: 'Please enter a valid email.' }
    ],
    'password': [
      { type: 'required', message: 'Password is required.' },
     
    ],
    };
  signup(values){
    this.show_loader = true;
    this.service.register(values.name,values.email,values.password).subscribe(res => {
      console.log(res)
      window.localStorage.setItem('user_id',res['user_id'])
      window.localStorage.setItem('name',res['name'])
      this.show_loader = false;
      if(res['result'] == false ) {
        this.showmessage(res['message'])
      }else{
      this.navCtrl.navigateForward('intro', { animated: false, });
    }
    })
  }
  signin(){
    this.navCtrl.navigateForward('login', { animated: false, });
  }
  async showmessage(message){
    var toast = await this.toastController.create({
      message: message,
      cssClass: 'alert-controller-css',
      color:'danger',
      duration: 3000
    });
    toast.present();
   
    }
}
