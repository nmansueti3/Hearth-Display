import { MbscModule } from '@mobiscroll/angular';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GooglePlus } from '@ionic-native/google-plus/ngx';
import { NegativeProgressModalPageModule } from './negative-progress-modal/negative-progress-modal.module';
//import { Calendar } from '@fullcalendar/core';
import { FullCalendarModule } from '@fullcalendar/angular'; // the main connector. must go first
import { HttpClientModule, HttpClientJsonpModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { NativeRingtones } from '@ionic-native/native-ringtones/ngx';
import { Media, MediaObject } from '@ionic-native/media/ngx';

@NgModule({
  declarations: [AppComponent],
  entryComponents: [],
  imports: [ 
    MbscModule, BrowserModule, IonicModule.forRoot(), AppRoutingModule,
    FormsModule,
    HttpModule,
    FullCalendarModule ,
    ReactiveFormsModule,
    NegativeProgressModalPageModule,
    HttpClientModule,
    HttpClientJsonpModule
  ],
  providers: [
    StatusBar,
    GooglePlus,
    Camera,
    Media,
    NativeRingtones,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
