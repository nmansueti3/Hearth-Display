import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FreeTimeCountdownPage } from './free-time-countdown.page';

const routes: Routes = [
  {
    path: '',
    component: FreeTimeCountdownPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FreeTimeCountdownPageRoutingModule {}
