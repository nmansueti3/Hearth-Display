import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { BabyFrontScreenPage } from './baby-front-screen.page';

describe('BabyFrontScreenPage', () => {
  let component: BabyFrontScreenPage;
  let fixture: ComponentFixture<BabyFrontScreenPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BabyFrontScreenPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(BabyFrontScreenPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
