import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MomRestingScreenPageRoutingModule } from './mom-resting-screen-routing.module';

import { MomRestingScreenPage } from './mom-resting-screen.page';
import { NgCircleProgressModule } from 'ng-circle-progress';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NgCircleProgressModule.forRoot({
      radius: 100,
      outerStrokeWidth: 12,
      innerStrokeWidth: 0,
      outerStrokeColor: "#78C000",
      animationDuration: 300,
    }),
    MomRestingScreenPageRoutingModule
  ],
  declarations: [MomRestingScreenPage]
})
export class MomRestingScreenPageModule {}
