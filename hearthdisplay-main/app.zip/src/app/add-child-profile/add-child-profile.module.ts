import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddChildProfilePageRoutingModule } from './add-child-profile-routing.module';

import { AddChildProfilePage } from './add-child-profile.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AddChildProfilePageRoutingModule
  ],
  declarations: [AddChildProfilePage]
})
export class AddChildProfilePageModule {}
