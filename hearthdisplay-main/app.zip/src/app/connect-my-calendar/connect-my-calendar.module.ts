import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ConnectMyCalendarPageRoutingModule } from './connect-my-calendar-routing.module';

import { ConnectMyCalendarPage } from './connect-my-calendar.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ConnectMyCalendarPageRoutingModule
  ],
  declarations: [ConnectMyCalendarPage]
})
export class ConnectMyCalendarPageModule {}
