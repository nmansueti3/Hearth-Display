import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-save-profile',
  templateUrl: './save-profile.page.html',
  styleUrls: ['./save-profile.page.scss'],
})
export class SaveProfilePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
