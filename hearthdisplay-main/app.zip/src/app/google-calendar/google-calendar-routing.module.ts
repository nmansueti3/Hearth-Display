import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GoogleCalendarPage } from './google-calendar.page';

const routes: Routes = [
  {
    path: '',
    component: GoogleCalendarPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GoogleCalendarPageRoutingModule {}
