import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BabyCompleteRoutinePage } from './baby-complete-routine.page';

const routes: Routes = [
  {
    path: '',
    component: BabyCompleteRoutinePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BabyCompleteRoutinePageRoutingModule {}
