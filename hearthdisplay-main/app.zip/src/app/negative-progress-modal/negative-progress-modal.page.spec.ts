import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { NegativeProgressModalPage } from './negative-progress-modal.page';

describe('NegativeProgressModalPage', () => {
  let component: NegativeProgressModalPage;
  let fixture: ComponentFixture<NegativeProgressModalPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NegativeProgressModalPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(NegativeProgressModalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
