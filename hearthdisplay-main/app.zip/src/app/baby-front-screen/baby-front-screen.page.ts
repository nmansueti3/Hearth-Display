import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { RequestsService } from '../requests.service';
import { LoadingController,ToastController,AlertController  } from '@ionic/angular';
import { Router } from '@angular/router';
@Component({
  selector: 'app-baby-front-screen',
  templateUrl: './baby-front-screen.page.html',
  styleUrls: ['./baby-front-screen.page.scss'],
})
export class BabyFrontScreenPage implements OnInit {
  user_id: any
  baby_name: any
  baby_pic:any
  constructor(public router: Router,
    public navCtrl: NavController,public alertController: AlertController,
    public service:RequestsService,public loadingController:LoadingController){ 
      this.baby_pic = 'assets/images/image1.png';
    }

  ngOnInit() {
  }
  async ionViewDidEnter(){
    let loading = await this.loadingController.create({
      showBackdrop: false,
      mode: 'ios',
      cssClass: 'custom-loading'
  });
  
  loading.present().then(() => {
    this.user_id = window.localStorage.getItem('user_id')
    this.service.child_front_screen(this.user_id).subscribe(res => {
      console.log(res)
      this.baby_name = res['detail']['name'];
      this.baby_pic = res['detail']['image'];
      if(this.baby_pic!='https://propuae.com/hearth_api/images/'){
        window.localStorage.setItem('baby_pic',this.baby_pic)
      }else{
        this.baby_pic = 'assets/images/image1.png';
        window.localStorage.setItem('baby_pic',this.baby_pic)
      }
      loading.dismiss()
    })
  })
  }
}
