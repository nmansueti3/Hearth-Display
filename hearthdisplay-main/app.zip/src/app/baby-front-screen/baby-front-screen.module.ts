import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BabyFrontScreenPageRoutingModule } from './baby-front-screen-routing.module';

import { BabyFrontScreenPage } from './baby-front-screen.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BabyFrontScreenPageRoutingModule
  ],
  declarations: [BabyFrontScreenPage]
})
export class BabyFrontScreenPageModule {}
