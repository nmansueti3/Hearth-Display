import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddAnotherCalendarPageRoutingModule } from './add-another-calendar-routing.module';

import { AddAnotherCalendarPage } from './add-another-calendar.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AddAnotherCalendarPageRoutingModule
  ],
  declarations: [AddAnotherCalendarPage]
})
export class AddAnotherCalendarPageModule {}
