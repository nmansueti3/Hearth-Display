import { Component, AfterViewInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { RequestsService } from '../../requests.service';
import { LoadingController,ToastController,AlertController  } from '@ionic/angular';

@Component({
  selector: 'app-cal-modal',
  templateUrl: './cal-modal.page.html',
  styleUrls: ['./cal-modal.page.scss'],
})
export class CalModalPage   {
  event = {
    title: '',
    desc: '',
    startTime: '',
    endTime: '',
    allDay: false
  };
 user_id: any
  minDate = new Date().toISOString();
 
  eventSource = [];
  viewTitle;
 
  calendar = {
    mode: 'month',
    currentDate: new Date(),
  };
   constructor(private modalCtrl: ModalController,public service:RequestsService,
    public loadingController:LoadingController,public toastController:ToastController) { }
 
  save() {    
    this.modalCtrl.dismiss({event: this.eventSource})
  }
 
  addEvent() {
    console.log(this.event.title)
    if(this.event.title=='' || this.event.desc == '' || this.event.startTime == '' || this.event.endTime == ''){
      this.showmessage1('Please fill all EVENTS fields');
    }
    else{
    let eventCopy = {
      title: this.event.title,
      startTime:  new Date(this.event.startTime),
      endTime: new Date(this.event.endTime),
      allDay: this.event.allDay,
      desc: this.event.desc
    }
 
    // if (eventCopy.allDay) {
    //   let start = eventCopy.startTime;
    //   let end = eventCopy.endTime;
 
    //   eventCopy.startTime = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), start.getUTCDate()));
    //   eventCopy.endTime = new Date(Date.UTC(end.getUTCFullYear(), end.getUTCMonth(), end.getUTCDate() + 1));
    // }

    let splitEndDate = this.event.endTime.split('T');
    let end_date = splitEndDate[0];
    let end_time = splitEndDate[1].split('.');
    let clear_end_time = end_time[0]

    this.eventSource.push(eventCopy);
    this.user_id = window.localStorage.getItem('user_id')
    
    this.service.add_event(eventCopy.title,eventCopy.desc,eventCopy.startTime,eventCopy.endTime,
      this.user_id,end_date, clear_end_time).subscribe(res =>{
      console.log(res)
      if(res['result']==true){
        this.showmessage('Event Added Successfully!');
      }
    })
    
    this.modalCtrl.dismiss({event: this.eventSource})
  }
}
  
  async showmessage(message){
    var toast = await this.toastController.create({
      message: message,
      cssClass: 'alert-controller-css',
      color:'success',
      duration: 3000
    });
    toast.present();
   
    }
  
    async showmessage1(message){
      var toast = await this.toastController.create({
        message: message,
        cssClass: 'alert-controller-css',
        color:'danger',
        duration: 3000
      });
      toast.present();
     
      }

  close(){
    this.modalCtrl.dismiss();
  }
}
