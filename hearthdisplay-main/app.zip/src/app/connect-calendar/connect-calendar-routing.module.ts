import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ConnectCalendarPage } from './connect-calendar.page';

const routes: Routes = [
  {
    path: '',
    component: ConnectCalendarPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ConnectCalendarPageRoutingModule {}
