import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },

  {
    path: 'signup',
    loadChildren: () => import('./signup/signup.module').then( m => m.SignupPageModule)
  },
  {
    path: 'intro',
    loadChildren: () => import('./intro/intro.module').then( m => m.IntroPageModule)
  },
  {
    path: 'add-profile',
    loadChildren: () => import('./add-profile/add-profile.module').then( m => m.AddProfilePageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'save-profile',
    loadChildren: () => import('./save-profile/save-profile.module').then( m => m.SaveProfilePageModule)
  },
  {
    path: 'profile',
    loadChildren: () => import('./profile/profile.module').then( m => m.ProfilePageModule)
  },
  {
    path: 'add-more-profile',
    loadChildren: () => import('./add-more-profile/add-more-profile.module').then( m => m.AddMoreProfilePageModule)
  },
  {
    path: 'connect-calendar',
    loadChildren: () => import('./connect-calendar/connect-calendar.module').then( m => m.ConnectCalendarPageModule)
  },
  {
    path: 'connect-calendars',
    loadChildren: () => import('./connect-calendars/connect-calendars.module').then( m => m.ConnectCalendarsPageModule)
  },
  {
    path: 'connect-my-calendar',
    loadChildren: () => import('./connect-my-calendar/connect-my-calendar.module').then( m => m.ConnectMyCalendarPageModule)
  },
  {
    path: 'add-another-calendar',
    loadChildren: () => import('./add-another-calendar/add-another-calendar.module').then( m => m.AddAnotherCalendarPageModule)
  },
  {
    path: 'view-calendar',
    loadChildren: () => import('./view-calendar/view-calendar.module').then( m => m.ViewCalendarPageModule)
  },
  {
    path: 'google-calendar',
    loadChildren: () => import('./google-calendar/google-calendar.module').then( m => m.GoogleCalendarPageModule)
  },
  {
    path: 'profile-detail',
    loadChildren: () => import('./profile-detail/profile-detail.module').then( m => m.ProfileDetailPageModule)
  },
  {
    path: 'edit-profile',
    loadChildren: () => import('./edit-profile/edit-profile.module').then( m => m.EditProfilePageModule)
  },
  {
    path: 'splash',
    loadChildren: () => import('./splash/splash.module').then( m => m.SplashPageModule)
  },
  {
    path: 'baby-front-screen',
    loadChildren: () => import('./baby-front-screen/baby-front-screen.module').then( m => m.BabyFrontScreenPageModule)
  },
  {
    path: 'baby-complete-routine',
    loadChildren: () => import('./baby-complete-routine/baby-complete-routine.module').then( m => m.BabyCompleteRoutinePageModule)
  },
  {
    path: 'free-time-countdown',
    loadChildren: () => import('./free-time-countdown/free-time-countdown.module').then( m => m.FreeTimeCountdownPageModule)
  },
  {
    path: 'mom-resting-screen',
    loadChildren: () => import('./mom-resting-screen/mom-resting-screen.module').then( m => m.MomRestingScreenPageModule)
  },
  {
    path: 'end-resting-progress',
    loadChildren: () => import('./end-resting-progress/end-resting-progress.module').then( m => m.EndRestingProgressPageModule)
  },
  {
    path: 'negative-progress-modal',
    loadChildren: () => import('./negative-progress-modal/negative-progress-modal.module').then( m => m.NegativeProgressModalPageModule)
  },
  {
    path: 'cal-modal',
    loadChildren: () => import('./pages/cal-modal/cal-modal.module').then( m => m.CalModalPageModule)
  },
  {
    path: 'add-child-profile',
    loadChildren: () => import('./add-child-profile/add-child-profile.module').then( m => m.AddChildProfilePageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
