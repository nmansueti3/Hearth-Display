import { CalendarComponent } from 'ionic2-calendar';
import { Component, ViewChild, OnInit, Inject, LOCALE_ID } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { formatDate } from '@angular/common';
import { CalModalPage } from '../pages/cal-modal/cal-modal.page';
import { ModalController } from '@ionic/angular'; 
import { RequestsService } from '../requests.service';

@Component({
  selector: 'app-end-resting-progress',
  templateUrl: './end-resting-progress.page.html',
  styleUrls: ['./end-resting-progress.page.scss'],
})
export class EndRestingProgressPage implements OnInit {
  days:any;
  current_time:any;
  current_month:any;
  current_year:any;
  current_date:any;
  event = {
    title: '',
    desc: '',
    startTime: '',
    endTime: '',
    allDay: false
  };
 
  minDate = new Date().toISOString();
 
  eventSource = [];
  eventSource1 = [];
  viewTitle;
 
  calendar = {
    mode: 'month',
    currentDate: new Date(),
  };
  user_id:any
  @ViewChild(CalendarComponent) myCal: CalendarComponent;
 
  constructor(private alertCtrl: AlertController, @Inject(LOCALE_ID) private locale: string,
  private modalCtrl: ModalController,public service:RequestsService,) { }
 
  ngOnInit() {
    this.resetEvent();
  }
  ionViewDidEnter(){
    this.current_date = new Date().getDate().toString();
    this.current_year = new Date().getFullYear().toString();
    const monthNames = ["January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    const d = new Date();
    this.current_month = monthNames[d.getMonth()];
    let currentDate = new Date();
    let weekdays = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    this.days = weekdays[currentDate.getDay()];
    
    var intervalVar = setInterval(function () {
      let date = new Date(); 
      let time1 = new Date(date.getTime() - date.getTimezoneOffset()*60000).toISOString();
      let hoursMinutes =time1.split('T');
      this.current_time = this.formatAMPM(hoursMinutes[1].split(':'));
    }.bind(this),500)
    this.user_id = window.localStorage.getItem('user_id')
      this.loadEvents();
  }

  loadEvents() {
    this.service.get_events(this.user_id).subscribe(res => {
      for(let i =0 ; i<res['events'].length ; i++){
      this.eventSource1.push({title: res['events'][i].title,  startTime:  new Date(res['events'][i].start_time),
      endTime: new Date(res['events'][i].end_time),allDay: false,desc: res['events'][i].des});
      }
      this.eventSource = this.eventSource1;
    })
  }

  formatAMPM(date) {
    var hours = date[0];
    var minutes = date[1];
	  var ampm = hours >= 12 ? 'PM' : 'AM';
	  hours = hours % 12;
	  hours = hours ? hours : 12;
	  // minutes = minutes < 10 ? '0'+minutes : minutes;
	  var strTime = hours + ':' + minutes + ' ' + ampm;
	  return strTime;
}
  resetEvent() {
    this.event = {
      title: '',
      desc: '',
      startTime: new Date().toISOString(),
      endTime: new Date().toISOString(),
      allDay: false
    };
  }
 
  // Change current month/week/day
 next() {
  var swiper = document.querySelector('.swiper-container')['swiper'];
  swiper.slideNext();
}
 
back() {
  var swiper = document.querySelector('.swiper-container')['swiper'];
  swiper.slidePrev();
}
 
// Change between month/week/day
changeMode(mode) {
  this.calendar.mode = mode;
}
 
// Focus today
today() {
  this.calendar.currentDate = new Date();
}
 
// Selected date reange and hence title changed
onViewTitleChanged(title) {
  this.viewTitle = title;
}
 
// Calendar event was clicked
async onEventSelected(event) {
  // Use Angular date pipe for conversion
  let start = formatDate(event.startTime, 'medium', this.locale);
  let end = formatDate(event.endTime, 'medium', this.locale);
 
  const alert = await this.alertCtrl.create({
    header: event.title,
    subHeader: event.desc,
    message: 'From: ' + start + '<br><br>To: ' + end,
    buttons: ['OK']
  });
  alert.present();
}
 
// Time slot was clicked
onTimeSelected(ev) {
  let selected = new Date(ev.selectedTime);
  this.event.startTime = selected.toISOString();
  selected.setHours(selected.getHours() + 1);
  this.event.endTime = (selected.toISOString());
} 

async openCalModal() {
  const modal = await this.modalCtrl.create({
    component: CalModalPage,
    cssClass: 'cal-modal',
    backdropDismiss: false
  });
 
  await modal.present();
 
  modal.onDidDismiss().then((result) => {
    if (result.data && result.data.event) {
      //let event = result.data.event;
    //  this.eventSource=result.data.event;
      //console.log(this.eventSource)
      this.loadEvents();     
      //this.myCal.loadEvents();
    }
  });
}
}