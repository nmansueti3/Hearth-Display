import { Component, OnInit } from '@angular/core';
import 'rxjs/add/observable/of';
import { Router } from '@angular/router';
@Component({
  selector: 'app-free-time-countdown',
  templateUrl: './free-time-countdown.page.html',
  styleUrls: ['./free-time-countdown.page.scss'],
})
export class FreeTimeCountdownPage implements OnInit {
  value:any;
  count:any;
  routines:any=[];
  days:any;
  today:any;
  time:any;
  count_hours:any;
  count_minutes:any;
  count_seconds:any;
  percent_progress:any;
  user_id: any;
  compareDate:any;
  currentDate:any;
  currentTime:any;
  curr_playing_file:any;
  store_file:any;
  profile_pic:any
    constructor(public router:Router) { 
      this.value = '23'
      this.count = 0;
      this.routines = [{
        'action_img':'assets/images/clean_washroom.png',
        'name':'clean bathroom',
        'check':'false',
        'type':'optional'
      },{
        'action_img':'assets/images/empty_dishwasher.png',
        'name':'empty dishwasher',
        'check':'false',
        'type':'optional'
      }]
    }
  
    ngOnInit() {
    }
    ionViewDidEnter(){
    this.user_id = window.localStorage.getItem('user_id')
    this.profile_pic =  window.localStorage.getItem('baby_pic');
    let currentDate = new Date();
    let weekdays = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    this.days = weekdays[currentDate.getDay()];
    var intervalVar = setInterval(function () {
      let date = new Date(); 
      let time1 = new Date(date.getTime() - date.getTimezoneOffset()*60000).toISOString();
      let hoursMinutes =time1.split('T');
      this.currentDate = hoursMinutes[0]
      let splitTime =hoursMinutes[1].split('.')
      this.currentTime = splitTime[0];
      this.time = this.formatAMPM(hoursMinutes[1].split(':'));
    }.bind(this),500)

      let date = new Date(); 
      let time1 = new Date(date.getTime() - date.getTimezoneOffset()*60000).toISOString();
      let hoursMinutes =time1.split('T');
      this.currentDate = hoursMinutes[0]
      let splitTime =hoursMinutes[1].split('.')
      this.currentTime = splitTime[0];
    // this.service.child_events(this.user_id,this.currentDate,this.currentTime).subscribe(res => {
    //   console.log(res)
    //   let end_time = res['end_time'];
    //   let current_time = res['current_time'];
     
    var timer;

    var compareDate = new Date();
    console.log(compareDate)

    compareDate.setDate(compareDate.getDate()); //just for this demo today + 7 days
    console.log(compareDate)

    timer = setInterval(function() {
      this.timeBetweenDates(compareDate,timer);
    }.bind(this),1000);
// }) 
  }
   timeBetweenDates(toDate,timer) {
  //  console.log(toDate)
    var dateEntered = toDate;
    var now = new Date();
    var difference = dateEntered.getTime() + 2000000 - now.getTime();

    if (difference <= 0) {
      // Timer done
      clearInterval(timer);
    
    } else {
      
      var seconds = Math.floor(difference / 1000);
      var minutes = Math.floor(seconds / 60);
      var hours = Math.floor(minutes / 60);
      var days = Math.floor(hours / 24);
  
      hours %= 24;
      minutes %= 60;
      seconds %= 60;
      this.count_hours =  hours ;
      let total_minutes = minutes + hours * 60 ;
      if(total_minutes<10)
      this.count_minutes = '0'+total_minutes;
      else
      this.count_minutes = total_minutes;
      if(seconds<10)
      this.count_seconds = '0'+seconds;
      else
      this.count_seconds = seconds
    
    }
  }
  
  formatAMPM(date) {
    var hours = date[0];
    var minutes = date[1];
	  var ampm = hours >= 12 ? 'PM' : 'AM';
	  hours = hours % 12;
	  hours = hours ? hours : 12;
	  // minutes = minutes < 10 ? '0'+minutes : minutes;
	  var strTime = hours + ':' + minutes + ' ' + ampm;
	  return strTime;
}
    select(index,name,action_img,type) {
      console.log(type)
      this.routines[index]={action_img:action_img,name:name,star_img:'assets/images/star_check.png',
      check:'true',type:type}
      this.count = this.count + 1;
      console.log(this.count)
    }
    free_time(){
      this.router.navigate(['/free-time-countdown'])
    }
  }
  