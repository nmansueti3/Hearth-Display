import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { RequestsService } from '../requests.service';
import { LoadingController,ToastController,AlertController  } from '@ionic/angular';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  show_loader:any;
  validations_form: FormGroup;
  constructor(public navCtrl: NavController,
    public formBuilder: FormBuilder, public service:RequestsService,
    public toastController:ToastController) { 
    this.show_loader=false;
  }

    ngOnInit() {
      this.validations_form = this.formBuilder.group({
        password: new FormControl('', Validators.required),
        email: new FormControl('', Validators.compose([
          Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
        ])),
    
       });
    }
    
    validation_messages = {
     
      'email': [
        { type: 'required', message: 'Email is required.' },
        { type: 'pattern', message: 'Please enter a valid email.' }
      ],
      'password': [
        { type: 'required', message: 'Password is required.' },
       
      ],
      };
  
  signup(){
    this.navCtrl.navigateForward('signup', { animated: false, });
  }
  signin(values){
    this.show_loader = true;
    this.service.login(values.email,values.password).subscribe(res => {
      console.log(res)
      this.show_loader = false;
      window.localStorage.setItem('user_id',res['user_id'])
      window.localStorage.setItem('name',res['name'])
      if(res['result'] == false ) {
        this.showmessage(res['message'])
      }else{
      if(res['user_type']=='parent'){
        this.navCtrl.navigateForward('profile', { animated: false, });
      }else{
        this.navCtrl.navigateForward('baby-front-screen', { animated: false, });
      }
    }
    })
  }
  async showmessage(message){
    var toast = await this.toastController.create({
      message: message,
      cssClass: 'alert-controller-css',
      color:'danger',
      duration: 3000
    });
    toast.present();
   
    }
}
