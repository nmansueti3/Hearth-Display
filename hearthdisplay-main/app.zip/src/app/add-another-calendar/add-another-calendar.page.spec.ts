import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AddAnotherCalendarPage } from './add-another-calendar.page';

describe('AddAnotherCalendarPage', () => {
  let component: AddAnotherCalendarPage;
  let fixture: ComponentFixture<AddAnotherCalendarPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddAnotherCalendarPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AddAnotherCalendarPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
