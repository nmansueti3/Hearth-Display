import { Component, OnInit } from '@angular/core';
import { GooglePlus } from '@ionic-native/google-plus/ngx';
import { LoadingController,ToastController,AlertController  } from '@ionic/angular';

@Component({
  selector: 'app-google-calendar',
  templateUrl: './google-calendar.page.html',
  styleUrls: ['./google-calendar.page.scss'],
})
export class GoogleCalendarPage implements OnInit {

  constructor( private googlePlus:GooglePlus,
    public toastController:ToastController) { }

  ngOnInit() {
  }
  ionViewDidEnter(){
    this.googlePlus.login({})
    .then(result => console.log(result)
    )
    .catch(err => this.showmessage(JSON.stringify(err)));
   }
   async showmessage(message){
    var toast = await this.toastController.create({
      message: message,
      duration: 3000
    });
    toast.present();
   
    }
}
