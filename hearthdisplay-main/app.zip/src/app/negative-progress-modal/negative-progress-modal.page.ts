import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
@Component({
  selector: 'app-negative-progress-modal',
  templateUrl: './negative-progress-modal.page.html',
  styleUrls: ['./negative-progress-modal.page.scss'],
})
export class NegativeProgressModalPage implements OnInit {

  constructor(private modalCtrl:ModalController,) { }

  ngOnInit() {
  }
  dismiss(){
    this.modalCtrl.dismiss();
  }
}
