import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BabyFrontScreenPage } from './baby-front-screen.page';

const routes: Routes = [
  {
    path: '',
    component: BabyFrontScreenPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BabyFrontScreenPageRoutingModule {}
