import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { RequestsService } from '../requests.service';
import { LoadingController,ToastController,AlertController  } from '@ionic/angular';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add-more-profile',
  templateUrl: './add-more-profile.page.html',
  styleUrls: ['./add-more-profile.page.scss'],
})
export class AddMoreProfilePage implements OnInit {
  user_id:any
  profiles:any=[];
  constructor(public router: Router,
    public navCtrl: NavController,public alertController: AlertController,
    public service:RequestsService,public loadingController:LoadingController) { }

  ngOnInit() {
  }
  async ionViewDidEnter(){
    this.user_id = window.localStorage.getItem('user_id');
    let loading = await this.loadingController.create({
      showBackdrop: false,
      mode: 'ios',
      cssClass: 'custom-loading'
  });
  
  loading.present().then(() => {
  this.service.all_profiles(this.user_id).subscribe(res => {
    console.log(res)
    loading.dismiss();
    this.profiles = res['all_profiles'];
    });
  });
}
  add_profile(){
    this.router.navigate(['add-child-profile']);
  }
  profile_detail(id){
    window.localStorage.setItem('detail_id',id)
    this.router.navigate(['profile-detail'])
  }
}
