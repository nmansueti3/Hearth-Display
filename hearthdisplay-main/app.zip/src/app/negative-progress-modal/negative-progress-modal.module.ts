import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { NegativeProgressModalPageRoutingModule } from './negative-progress-modal-routing.module';

import { NegativeProgressModalPage } from './negative-progress-modal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NegativeProgressModalPageRoutingModule
  ],
  declarations: [NegativeProgressModalPage]
})
export class NegativeProgressModalPageModule {}
