import { Component, OnInit } from '@angular/core';
import { NegativeProgressModalPage } from '../negative-progress-modal/negative-progress-modal.page';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-mom-resting-screen',
  templateUrl: './mom-resting-screen.page.html',
  styleUrls: ['./mom-resting-screen.page.scss'],
})
export class MomRestingScreenPage implements OnInit {

  constructor(private modalCtrl:ModalController,) { }

  ngOnInit() {
  }

  async ionViewDidEnter(){
    const modal = await this.modalCtrl.create({
      component: NegativeProgressModalPage,
      cssClass: 'my-custom-modal-css',
    });
     modal.present();
  }

}
